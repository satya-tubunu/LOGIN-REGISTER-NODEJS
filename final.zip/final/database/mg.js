const mongoose = require('mongoose')

//just connect your data base